# SINA Institute LMS

A simple full-stack Learning Management System for SINA Institute.

## Features
- Five courses: Digital Marketing, Web Designing, AutoCAD, Safety Officer, Computer Application.
- Principal and course instructor information.
- Enrollment form with name, CNIC, phone and optional email.
- CNIC validation (13 digits).
- A student/CNIC can enroll in only one course. This is checked on the server, not just in the browser.
- Successful enrollment confirmation and enrollment ID.
- Express backend routes and a persistent JSON data file. No MySQL or separate database installation is needed.

## Requirements
Install Node.js (LTS) from https://nodejs.org/. Then open this project folder in VS Code.

## Run on Windows
1. Open the `SINA-LMS` folder in VS Code.
2. Open Terminal > New Terminal.
3. Run:

   ```bash
   npm install
   npm start
   ```

4. Open `http://localhost:3000` in Chrome.

**Important:** Run `npm install` and `npm start` from the folder that contains `package.json`, not from its parent folder.

## Backend API
- `GET /api/health` - server health check.
- `GET /api/courses` - list courses.
- `GET /api/enrollments/check?cnic=13digits` - check whether a CNIC is already enrolled.
- `POST /api/enrollments` - create an enrollment.

Example POST body:

   ```json
   {
     "name": "Student Name",
     "cnic": "1234512345671",
     "phone": "03001234567",
     "email": "student@example.com",
     "courseId": "web-designing"
   }
   ```

## Data storage
Enrollment records are saved in `data/enrollments.json`. The server creates this file automatically on first run. Keep this file safe because it contains students' personal information. Do not upload it to a public repository or share it publicly.

## Before real-world/public launch
This is a starter project, not a production student-information system. Add HTTPS, authenticated admin access, backups, access controls, privacy/consent notices and a secure database with proper concurrency protection before collecting real CNIC information at scale. Do not expose the enrollment JSON file through the public folder.
