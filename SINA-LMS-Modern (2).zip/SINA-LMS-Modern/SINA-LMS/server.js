const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, "data");
const DB_FILE = path.join(DATA_DIR, "enrollments.json");

app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public")));

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, "[]", "utf8");

const courses = [
  { id: "digital-marketing", title: "Digital Marketing", teacher: "Ma'am Aliya", icon: "📈", duration: "3 Months", level: "Beginner to Advanced", description: "Learn social media marketing, SEO, content strategy, paid advertising, analytics and practical campaign planning." },
  { id: "web-designing", title: "Web Designing", teacher: "Ma'am Aliya", icon: "💻", duration: "3 Months", level: "Beginner to Advanced", description: "Build modern responsive websites using HTML, CSS, JavaScript and practical design principles." },
  { id: "autocad", title: "AutoCAD", teacher: "Sir Sabor", icon: "📐", duration: "3 Months", level: "Beginner", description: "Learn technical drawing, drafting tools, dimensions, layouts and professional 2D drawing workflows." },
  { id: "safety-officer", title: "Safety Officer", teacher: "Sir Sabor", icon: "🦺", duration: "3 Months", level: "Beginner", description: "Understand workplace hazards, risk assessment, PPE, safety procedures and emergency response." },
  { id: "computer-application", title: "Computer Application", teacher: "Ma'am Sehrish", icon: "🖥️", duration: "3 Months", level: "Beginner", description: "Develop everyday computer skills, file management, internet use and essential office application skills." }
];

function readEnrollments() {
  try {
    const data = JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}
function saveEnrollments(rows) {
  fs.writeFileSync(DB_FILE, JSON.stringify(rows, null, 2), "utf8");
}
function clean(value) {
  return String(value || "").trim().replace(/[<>]/g, "");
}
function normalizeCnic(value) {
  return String(value || "").replace(/\D/g, "");
}

app.get("/api/health", (req, res) => res.json({ status: "ok", app: "SINA LMS" }));
app.get("/api/courses", (req, res) => res.json({ courses }));
app.get("/api/enrollments/check", (req, res) => {
  const cnic = normalizeCnic(req.query.cnic);
  if (!/^\d{13}$/.test(cnic)) return res.status(400).json({ message: "Please provide a valid 13-digit CNIC." });
  const existing = readEnrollments().find(item => item.cnic === cnic);
  res.json({ enrolled: Boolean(existing), course: existing ? existing.courseTitle : null });
});

app.post("/api/enrollments", (req, res) => {
  const name = clean(req.body.name);
  const cnic = normalizeCnic(req.body.cnic);
  const phone = clean(req.body.phone);
  const email = clean(req.body.email);
  const courseId = clean(req.body.courseId);

  if (name.length < 2 || name.length > 80) {
    return res.status(400).json({ message: "Please enter your full name (2–80 characters)." });
  }
  if (!/^\d{13}$/.test(cnic)) {
    return res.status(400).json({ message: "CNIC must contain exactly 13 digits." });
  }
  if (!/^[0-9+()\-\s]{7,20}$/.test(phone)) {
    return res.status(400).json({ message: "Please enter a valid phone number." });
  }
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({ message: "Please enter a valid email address." });
  }

  const course = courses.find(item => item.id === courseId);
  if (!course) return res.status(400).json({ message: "Please select a valid course." });

  const enrollments = readEnrollments();
  const previous = enrollments.find(item => item.cnic === cnic);
  if (previous) {
    return res.status(409).json({
      message: `This CNIC is already enrolled in ${previous.courseTitle}. One student can enroll in only one course.`
    });
  }

  const enrollment = {
    id: `SINA-${Date.now()}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`,
    name, cnic, phone, email, courseId,
    courseTitle: course.title,
    teacher: course.teacher,
    createdAt: new Date().toISOString()
  };
  enrollments.push(enrollment);
  saveEnrollments(enrollments);

  return res.status(201).json({
    success: true,
    message: "You are successfully enrolled!",
    enrollment: { id: enrollment.id, name, courseTitle: course.title, teacher: course.teacher }
  });
});

// Friendly fallback for unknown API routes.
app.use("/api", (req, res) => res.status(404).json({ message: "API route not found." }));

app.listen(PORT, () => {
  console.log(`SINA LMS is running at http://localhost:${PORT}`);
});
