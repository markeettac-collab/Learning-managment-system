const courseGrid = document.getElementById("courseGrid");
const modal = document.getElementById("enrollModal");
const form = document.getElementById("enrollmentForm");
const formMessage = document.getElementById("formMessage");
const submitBtn = document.getElementById("submitBtn");
const successPanel = document.getElementById("successPanel");
const cnicInput = document.getElementById("cnic");

document.getElementById("year").textContent = new Date().getFullYear();

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);
}

async function loadCourses() {
  try {
    const response = await fetch("/api/courses");
    if (!response.ok) throw new Error("Could not load courses.");
    const data = await response.json();
    const coursePhotos = {
      "digital-marketing": "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1000&q=85",
      "web-designing": "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1000&q=85",
      "autocad": "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1000&q=85",
      "safety-officer": "https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=1000&q=85",
      "computer-application": "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1000&q=85"
    };
    courseGrid.innerHTML = data.courses.map((course, index) => `
      <article class="course-card">
        <div class="course-image-wrap">
          <img class="course-image" src="${coursePhotos[course.id] || coursePhotos["computer-application"]}" alt="${escapeHtml(course.title)} course" loading="lazy">
          <span class="course-number">0${index + 1} / 05</span>
          <div class="course-icon">${course.icon}</div>
        </div>
        <h3>${escapeHtml(course.title)}</h3>
        <p>${escapeHtml(course.description)}</p>
        <div class="course-meta"><span>◷ ${escapeHtml(course.duration)}</span><span>✦ ${escapeHtml(course.level)}</span></div>
        <div class="course-teacher">Instructor: <b>${escapeHtml(course.teacher)}</b></div>
        <button class="enroll-btn" data-course="${escapeHtml(course.id)}" data-title="${escapeHtml(course.title)}">Enroll Now <span>↗</span></button>
      </article>
    `).join("");
  } catch (error) {
    courseGrid.innerHTML = `<p class="form-message">${escapeHtml(error.message)} Please refresh the page.</p>`;
  }
}

function openEnrollment(courseId, title) {
  form.reset();
  document.getElementById("courseId").value = courseId;
  document.getElementById("selectedCourse").textContent = `You are applying for: ${title}`;
  document.getElementById("modalTitle").innerHTML = `Start your <em>journey.</em>`;
  form.style.display = "block";
  successPanel.hidden = true;
  formMessage.textContent = "";
  submitBtn.disabled = false;
  submitBtn.innerHTML = 'Submit Enrollment <span>↗</span>';
  modal.classList.add("open");
  modal.setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";
  setTimeout(() => document.getElementById("name").focus(), 100);
}
function closeModal() {
  modal.classList.remove("open");
  modal.setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
}
courseGrid.addEventListener("click", event => {
  const button = event.target.closest("[data-course]");
  if (button) openEnrollment(button.dataset.course, button.dataset.title);
});
document.getElementById("modalClose").addEventListener("click", closeModal);
document.getElementById("successClose").addEventListener("click", closeModal);
modal.addEventListener("click", event => { if (event.target === modal) closeModal(); });
document.addEventListener("keydown", event => { if (event.key === "Escape" && modal.classList.contains("open")) closeModal(); });

cnicInput.addEventListener("input", () => {
  const digits = cnicInput.value.replace(/\D/g, "").slice(0, 13);
  cnicInput.value = digits.length > 12 ? `${digits.slice(0,5)}-${digits.slice(5,12)}-${digits.slice(12)}` :
    digits.length > 5 ? `${digits.slice(0,5)}-${digits.slice(5)}` : digits;
});

form.addEventListener("submit", async event => {
  event.preventDefault();
  formMessage.textContent = "";
  const payload = {
    name: document.getElementById("name").value.trim(),
    cnic: document.getElementById("cnic").value.replace(/\D/g, ""),
    phone: document.getElementById("phone").value.trim(),
    email: document.getElementById("email").value.trim(),
    courseId: form.courseId.value
  };
  if (payload.cnic.length !== 13) {
    formMessage.textContent = "Please enter a complete 13-digit CNIC.";
    cnicInput.focus();
    return;
  }
  submitBtn.disabled = true;
  submitBtn.textContent = "Submitting...";
  try {
    const response = await fetch("/api/enrollments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.message || "Enrollment could not be completed.");
    form.style.display = "none";
    successPanel.hidden = false;
    document.getElementById("modalTitle").innerHTML = `You're <em>in!</em>`;
    document.getElementById("successText").textContent =
      `${result.enrollment.name}, your enrollment request for ${result.enrollment.courseTitle} has been recorded. Your enrollment ID is ${result.enrollment.id}.`;
  } catch (error) {
    formMessage.textContent = error.message;
    submitBtn.disabled = false;
    submitBtn.innerHTML = 'Submit Enrollment <span>↗</span>';
  }
});

document.getElementById("menuToggle").addEventListener("click", () => {
  document.getElementById("nav").classList.toggle("show");
});
document.querySelectorAll("#nav a").forEach(link => link.addEventListener("click", () => {
  document.getElementById("nav").classList.remove("show");
}));

loadCourses();
